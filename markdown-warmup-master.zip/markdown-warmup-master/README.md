# markdown-warmup

## BeCode La Prairie Group Exercise
====================================

 - Which website ?

[<h1>Nos Amis les Lapins](http://nosamisleslapin.e-monsite.com/)

### :shit: :fire: :rabbit::rabbit::rabbit::rabbit::rabbit::rabbit::rabbit::fire::shit:
![http://www.e-monsite.com/s/2010/02/06/nosamisleslapin//12678914photo-logo-jpg.jpg](http://www.e-monsite.com/s/2010/02/06/nosamisleslapin//12678914photo-logo-jpg.jpg)


 - Is it updated frequently ?
 
 No, Last update was nearly **8** years ago.
ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg
 - How did you find it ?
 
 By searching in [Google](http://google.com) the terms *Friends & Animals*.

 - Why this website needs updates or a remake ?
 
 This website needs updates because it uses **Deprecated technologies**, Since the time it was put online there has been many updates to *HTML* and *CSS*.

 - Is this website present on social networks ?
 
 This website is not present on social networks, this may be because at the time it was made, social networks weren't as proeminent as now. Another reason is the author *seems* to be a child and its possible they were not authorized by their family to have a social media profile.

 - Make a list of recomandation of the future changes ?
 
 Many changes can be made to the website, for example:
 1. A new *CSS* stylesheet could be used, to give the site a fresh look.
 1. Advertisements should be removed, as its not a website with a commercial goal.
 1. A basic update should be done to make the website dynamic and mobile compatible.

[https://assets-cdn.github.com/images/modules/open_graph/github-octocat.png]
![http://nosamisleslapin.e-monsite.com/medias/album/images/nougat.png?fx=r_550_550](http://nosamisleslapin.e-monsite.com/medias/album/images/nougat.png?fx=r_550_550)

~~Run rabbit run~~
Run rabbit – run rabbit – Run! Run! Run!
Run rabbit – run rabbit – Run! Run! Run!
Bang! Bang! Bang! Bang!
Goes the farmer's gun.
Run, rabbit, run, rabbit, run.
